//Questão 3
import React from 'react'
import Arena from '../questao01/Arena'
const  World = (props) => {
    return (
        <div>
            {props.children}
        </div>
    )
} 

export default World